package com.tcs.GraphQL.Gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphQlGatewayApplication.class, args);
	}

}
